/*
    Universidad de Las Americas (UDLA) - Campus Park
    Carrera: Ingenieria en Inteligencia Artificial
    Materia: Programacion 1
    Proyecto: Sistema de Gestion de Inventario 
    Nombres Estudiantes: Matías Moya, Esteban Rojas, Anthony Loor
    Fecha: 2026-04-18
*/

#include <stdio.h>
#include "inventario.h" 

int main() {
    // Declaramos nuestros Arreglos Paralelos en el archivo principal
    char nombres[10][20];   // Vector para 10 nombres de hasta 20 letras
    float precios[3][10];   // Matriz: 3 Sucursales X 10 Productos
    int cantidades[3][10];  // Matriz: 3 Sucursales X 10 Productos
    
    int num_productos = 0, opcion;

    printf("                                         \n");
    printf("   SISTEMA DE INVENTARIO - 3 SUCURSALES\n");
    printf("                                         \n");

    // 1. Validación de cantidad de productos
   
    do {
        printf("\n¿Cuantos productos desea registrar? (Maximo 10): ");
        
        // La "escoba" que limpia letras si intentan meter texto en vez de numeros
        if (scanf("%d", &num_productos) != 1) {
            printf("Error: Ingrese un numero valido.\n");
            while (getchar() != '\n'); 
            num_productos = 0;
        } 
        // Validación de límite máximo
        else if (num_productos < 1 || num_productos > 10) {
            printf("Error: Maximo 10 productos permitidos.\n");
        }
    } while (num_productos < 1 || num_productos > 10);

    // Llamamos a la primera función para empezar a llenar los arreglos
    ingresarDatos(nombres, precios, cantidades, num_productos);


    // 2. Menú Interactivo (Ciclo Infinito hasta elegir '6')

    do {
        printf("\n                MENU PRINCIPAL             \n");
        printf("1. Precio total del inventario por sucursal\n");
        printf("2. Producto mas caro y mas barato por sucursal\n");
        printf("3. Precio promedio por sucursal\n");
        printf("4. Buscar producto por nombre\n");
        printf("5. Total de unidades y alertas de stock\n");
        printf("6. Salir\n");
        printf("                                             \n");
        printf("Elija una opcion: ");
        
        // Validación para evitar bucles si eligen una letra en el menú
        if (scanf("%d", &opcion) != 1) {
            printf("Error: Ingrese solo numeros.\n");
            while (getchar() != '\n'); 
            opcion = 0;
            continue;
        }

        // El Switch llama a la función correspondiente y le envía las matrices que necesite
        switch (opcion) {
            case 1: calcularTotalPorSucursal(precios, cantidades, num_productos); break;
            case 2: encontrarExtremosPorSucursal(nombres, precios, num_productos); break;
            case 3: calcularPromedioPorSucursal(precios, num_productos); break;
            case 4: buscarProducto(nombres, precios, num_productos); break;
            case 5: calcularTotalUnidadesPorSucursal(nombres, cantidades, num_productos); break;
            case 6: printf("\nSaliendo del sistema... ¡Exito!\n"); break;
            default: printf("\nOpcion invalida.\n");
        }
    } while (opcion != 6);

    return 0; // Fin del programa
}
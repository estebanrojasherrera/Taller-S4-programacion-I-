/*
    Universidad de Las Americas UDLA - Campus Park
    Carrera: Ingenieria en Inteligencia Artificial
    Materia: Programacion 1
    Proyecto: Sistema de Gestion de Inventario 
    Nombres Estudiantes: Matías Moya, Esteban Rojas, Anthony Loor
    Fecha: 2026-04-18
*/

// ARCHIVO: inventario.h
// Contiene las firmas de las funciones para que el main.c las reconozca.

// Estos son los "Guardias de Seguridad" que evitan que el código se duplique por accidente.
#ifndef INVENTARIO_H
#define INVENTARIO_H

// 1. Función para registrar datos. Exige la matriz de nombres, precios, cantidades y el total de productos.
void ingresarDatos(char nombres[10][20], float precios[3][10], int cantidades[3][10], int num_productos);

// 2. Función para multiplicar precio por cantidad y sacar el total de cada sucursal.
void calcularTotalPorSucursal(float precios[3][10], int cantidades[3][10], int num_productos);

// 3. Función que compara precios para sacar el máximo y el mínimo.
void encontrarExtremosPorSucursal(char nombres[10][20], float precios[3][10], int num_productos);

// 4. Función que suma los precios y los divide para el total de productos.
void calcularPromedioPorSucursal(float precios[3][10], int num_productos);

// 5. Función de búsqueda (Valor Agregado con string.h).
void buscarProducto(char nombres[10][20], float precios[3][10], int num_productos);

// 6. Función que suma cantidades y lanza alerta si hay 5 o menos (Valor Agregado).
void calcularTotalUnidadesPorSucursal(char nombres[10][20], int cantidades[3][10], int num_productos);

#endif
/*
    Universidad de Las Americas (UDLA) - Campus Park
    Carrera: Ingenieria en Inteligencia Artificial
    Materia: Programacion 1
    Proyecto: Sistema de Gestion de Inventario
    Nombres Estudiantes: Matías Moya, Esteban Rojas, Anthony Loor
    Fecha: 2026-04-18
*/

#include <stdio.h>
#include <string.h> // VALOR AGREGADO 1: Nos permite usar 'strcmp' para comparar palabras.
#include "inventario.h"

// Arreglo global: Lo usamos solo para que sea más fácil imprimir "Norte", "Centro" o "Sur".
char nombres_sucursales[3][10] = {"Norte", "Centro", "Sur"};


// 1. Ingresar Datos

void ingresarDatos(char nombres[10][20], float precios[3][10], int cantidades[3][10], int num_productos) {
    printf("\n Registro de inventario \n");
    
    // Bucle externo: Recorre producto por producto (la letra 'p' es de producto)
    for (int p = 0; p < num_productos; p++) {
        printf("\nNombre del Producto %d: ", p + 1);
        scanf("%s", nombres[p]); // Guardamos el nombre en el vector

        // Bucle interno: Pide el precio y cantidad de ese mismo producto en las 3 sucursales ('s' es sucursal)
        for (int s = 0; s < 3; s++) {
            printf("  -> [Sucursal %s] Precio: $", nombres_sucursales[s]);
            scanf("%f", &precios[s][p]); // Guardamos cruzando fila (s) y columna (p)
            printf("  -> [Sucursal %s] Cantidad: ", nombres_sucursales[s]);
            scanf("%d", &cantidades[s][p]);
        }
    }
}


// 2. Calcular total de dinero por sucursal

void calcularTotalPorSucursal(float precios[3][10], int cantidades[3][10], int num_productos) {
    printf("\n Valor total del inventario por sucursal \n");
    
    // Recorremos sucursal por sucursal
    for (int s = 0; s < 3; s++) {
        float total_sucursal = 0.0; // Esta variable acumula el dinero
        
        for (int p = 0; p < num_productos; p++) {
            // Multiplicamos el precio por la cantidad que hay en stock y lo sumamos al total
            total_sucursal += (precios[s][p] * cantidades[s][p]);
        }
        // VALOR AGREGADO 2: Formato tabular. "%-8s" alinea el texto a la izquierda
        printf("Sucursal %-8s : $%.2f\n", nombres_sucursales[s], total_sucursal);
    }
}


// 3. Producto Más Caro y Más Barato

void encontrarExtremosPorSucursal(char nombres[10][20], float precios[3][10], int num_productos) {
    printf("\n Extremos de precio por sucursal \n");
    
    for (int s = 0; s < 3; s++) {
        // Asumimos que el primer producto de la lista es el más caro y el más barato al principio
        float max_precio = precios[s][0];
        float min_precio = precios[s][0];
        int indice_max = 0, indice_min = 0; // Guardan la posición para saber el nombre después

        // Comparamos el resto de los productos
        for (int p = 0; p < num_productos; p++) {
            if (precios[s][p] > max_precio) {
                max_precio = precios[s][p]; // Si encontramos uno mayor, actualizamos
                indice_max = p;
            }
            if (precios[s][p] < min_precio) {
                min_precio = precios[s][p]; // Si encontramos uno menor, actualizamos
                indice_min = p;
            }
        }
        // Imprimimos usando los índices guardados para sacar el nombre correcto
        printf("Sucursal %s:\n", nombres_sucursales[s]);
        printf("  + Caro:   %-10s ($%.2f)\n", nombres[indice_max], max_precio);
        printf("  - Barato: %-10s ($%.2f)\n", nombres[indice_min], min_precio);
    }
}

// 4. Promedio de precios

void calcularPromedioPorSucursal(float precios[3][10], int num_productos) {
    printf("\n Precio promedio por sucursal \n");
    for (int s = 0; s < 3; s++) {
        float suma_precios = 0.0;
        
        // Sumamos todos los precios de esa sucursal
        for (int p = 0; p < num_productos; p++) {
            suma_precios += precios[s][p];
        }
        // Imprimimos la suma dividida para el total de productos ingresados
        printf("Promedio en %-8s : $%.2f\n", nombres_sucursales[s], (suma_precios / num_productos));
    }
}

// 5. Buscar producto por nombre

void buscarProducto(char nombres[10][20], float precios[3][10], int num_productos) {
    char nombre_buscado[20];
    int encontrado = 0; // Se usa como bandera (0 = no encontrado, 1 = encontrado)

    printf("\n Buscador de productos \n");
    printf("Ingrese el nombre del producto a buscar: ");
    scanf("%s", nombre_buscado);

    for (int p = 0; p < num_productos; p++) {
        // strcmp compara dos textos. Si devuelve '0', significa que son idénticos.
        if (strcmp(nombres[p], nombre_buscado) == 0) { 
            printf("\nProducto encontrado: %s\n", nombres[p]);
            
            // Si lo encuentra, imprimimos su precio en las 3 sucursales
            for (int s = 0; s < 3; s++) {
                printf("  -> [Sucursal %s]: $%.2f\n", nombres_sucursales[s], precios[s][p]);
            }
            encontrado = 1; // Cambiamos la bandera
            break; // Rompemos el ciclo porque no hace falta seguir buscando
        }
    }
    // Si la bandera sigue en 0, es que el producto no existe
    if (encontrado == 0) printf("Error: El producto '%s' no existe.\n", nombre_buscado);
}


// 6. Unidades y Alertas de Stock Crítico

void calcularTotalUnidadesPorSucursal(char nombres[10][20], int cantidades[3][10], int num_productos) {
    printf("\n Unidades en inventario y alertas \n");
    
    for (int s = 0; s < 3; s++) {
        int total_unidades = 0; // Acumulador de productos
        printf("Sucursal %s:\n", nombres_sucursales[s]);
        
        for (int p = 0; p < num_productos; p++) {
            total_unidades += cantidades[s][p]; // Sumamos a la bodega
            
            // VALOR AGREGADO 3: Si hay 5 o menos, saltará esta alerta en la consola
            if (cantidades[s][p] <= 5) {
                printf("  [ALERTA] Stock critico de %s (%d unidades).\n", nombres[p], cantidades[s][p]);
            }
        }
        printf("  -> Total unidades almacenadas: %d\n\n", total_unidades);
    }
}